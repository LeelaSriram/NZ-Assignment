package com.westpac.common;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;

public class Westpac_NZ_HomeLoans {

	public static void main(String[] args) throws InterruptedException {

		// setting for browser driver
		System.setProperty("webdriver.ie.driver",
				"H:/Desktop/IEDriverServer.exe");

		// creating driver object based on different browsers
		// WebDriver driver = new FirefoxDriver();
		// WebDriver driver = new ChromeDriver();
		WebDriver driver = new InternetExplorerDriver();

		// declaring Url variable
		String baseUrl = "https://www.westpac.co.nz//";

		// launch Firefox and direct it to the Base URL
		driver.get(baseUrl);

		// verify home page after launching url
		// Westpac logo & login button is displayed or not
		if (driver.findElement(By.xpath(".//*[@id='logo']")).isDisplayed()
				|| driver
						.findElement(
								By.xpath("//header[@id='header-ps']//button[contains(text(),'Login')]"))
						.isDisplayed()) {

			System.out.println("Westpac NZ - Home page launched successfully");
		} else {
			System.out.println("Failed to launch Westpac NZ - Home page");

		}

		// verify different products are display or not in home page

		String[] arr = "Bank accounts;Home loans;Credit cards;Insurance;Investments;FX, travel & migrant;Managing your money;Branch, mobile & online"
				.split(";");

		for (int i = 0; i < arr.length; i++) {

			if (driver.findElement(
					By.xpath("//a[@id][contains(text(),\"" + arr[i] + "\")]"))
					.isDisplayed()) {

				System.out.println("product element \"" + arr[i]
						+ "\" is displayed successfully");
			} else {
				System.out.println("Failed to display product element \""
						+ arr[i] + "\"");

			}

		}

		// click on 'Home loans' product
		driver.findElement(By.xpath("//a[@id][contains(text(),'Home loans')]"))
				.click();

		// click on 'Apply online' button
		driver.findElement(By.xpath("//a[@title='Apply online']")).click();
		Thread.sleep(6000);

		// verify Header 'Apply online for a home loan'
		if (driver
				.findElement(
						By.xpath("//h1[contains(text(),'Apply online for a home loan')]"))
				.isDisplayed()) {

			System.out
					.println("Apply online -Header is displayed successfully");
		} else {
			System.out.println("Failed to display Apply online -Header");

		}

		Thread.sleep(6000);
		// click on 'No' for 'Are you a Westpac customer?'

		JavascriptExecutor js = (JavascriptExecutor) driver;
		// try{
		js.executeScript("arguments[0].click();", driver.findElement(By
				.xpath("//div[@id='view685']//div[contains(text(),'No')]")));
		// driver.findElement(By.xpath("//div[@id='view685']//div[contains(text(),'No')]")).click();

		// select title
		Select dropdown = new Select(driver.findElement(By
				.xpath(".//*[@id='view704']/span")));
		dropdown.selectByVisibleText("Mr");

		// Enter First name
		driver.findElement(By.xpath(".//*[@id='view712']")).sendKeys("Test");

		// Enter Last name
		driver.findElement(By.xpath(".//*[@id='view718']")).sendKeys(
				"Automation");

		// Enter phone number
		driver.findElement(By.xpath(".//*[@id='view725']")).sendKeys(
				"0212345678");

		// Enter email id
		driver.findElement(By.xpath(".//*[@id='view763']")).sendKeys(
				"test@testing.com");

		// select respective "yes or No" options for "Are you ..." section
		driver.findElement(
				By.xpath("//div[@id='view744']//div[contains(text(),'No')]"))
				.click();
		driver.findElement(
				By.xpath("//div[@id='view768']//div[contains(text(),'No')]"))
				.click();
		driver.findElement(
				By.xpath("//div[@id='view864']//div[contains(text(),'No')]"))
				.click();

		// Select loan purpose
		Select dropdown1 = new Select(driver.findElement(By
				.xpath(".//*[@id='view873']/span")));
		dropdown1.selectByVisibleText("Build a new home");

		// close Firefox
		driver.close();

		// exit the program explicitly
		System.exit(0);
	}

}
